<script setup></script>

<template>
    <section>
        <div class="relative w-full flex flex-col max-w-6xl mx-auto my-16 px-6 text-gray-800 md:flex-row md:px-0">
            <img src="../assets/desktop/image-interactive.jpg" alt="interactive" />
            <div class="top-48 pr-0 bg-white md:absolute md:right-0 md:py-20 md:pl-20">
                <h2 class="max-w-lg mt-10 mb-6 font-sans text-4xl text-center text-gray-800 uppercase md:text-5xl md:mt-0 md:text-left">
                    THE LEADER IN INTERACTIVE VR
                </h2>
                <p class="max-w-md text-center md:text-left">
                    Founded in 2011, Loopstudios has been producing would class virtal reality projects for some of the best companies around the globe. Our award winning creations have transformed businesses through digital experiences that bind to their brand.
                </p>
            </div>
        </div>
    </section>
</template>

<style scoped></style>